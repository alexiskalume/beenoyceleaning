'use client';
import { CheckCircle2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import Image from "next/image";
import placeholderImages from "@/lib/placeholder-images.json";

const AboutSection = () => {
  const { t } = useLanguage();

  const stats = [
    { value: "1000+", label: t.about.projectsCompleted },
    { value: "123+", label: t.about.expertCleaners },
    { value: "400+", label: t.about.loyalClients },
  ];

  return (
    <section id="about" className="py-12 gradient-hero overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Image */}
          <div className="relative animate-slide-in-from-left">
            <div className="relative">
              {/* Decorative background */}
              <div className="absolute -inset-4 bg-primary/10 rounded-3xl rotate-3" />
              
              <Image
                src={placeholderImages.about.cleanerPortrait.src}
                alt="Our cleaning team"
                width={placeholderImages.about.cleanerPortrait.width}
                height={placeholderImages.about.cleanerPortrait.height}
                data-ai-hint={placeholderImages.about.cleanerPortrait.hint}
                className="relative rounded-3xl shadow-elevated w-full object-cover aspect-[4/5]"
              />

              {/* Experience badge */}
              <div className="absolute -bottom-6 -right-6 bg-card rounded-2xl p-6 shadow-elevated">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full gradient-primary flex items-center justify-center">
                    <span className="text-primary-foreground font-bold text-2xl">16+</span>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-foreground">{t.about.years}</div>
                    <div className="text-muted-foreground">{t.about.ofExcellence}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-8 animate-slide-in-from-right">
            <div>
              <span className="text-primary font-semibold uppercase tracking-wider text-sm">
                {t.about.subtitle}
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
                {t.about.title}
              </h2>
            </div>

            <p className="text-muted-foreground text-lg">
              {t.about.description}
            </p>

            <div className="space-y-4">
              {[t.about.feature1, t.about.feature2, t.about.feature3, t.about.feature4].map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-accent" />
                  </div>
                  <span className="text-foreground font-medium">{item}</span>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
