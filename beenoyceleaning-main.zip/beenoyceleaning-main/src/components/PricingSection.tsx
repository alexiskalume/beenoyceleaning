'use client';
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import Link from "next/link";

const PricingSection = () => {
  const { t } = useLanguage();

  const plans = [
    {
      name: t.pricing.basic,
      price: "49",
      period: t.pricing.perVisit,
      description: t.pricing.basicDesc,
      features: t.pricing.basicFeatures,
      popular: false,
    },
    {
      name: t.pricing.standard,
      price: "89",
      period: t.pricing.perVisit,
      description: t.pricing.standardDesc,
      features: t.pricing.standardFeatures,
      popular: true,
    },
    {
      name: t.pricing.premium,
      price: "149",
      period: t.pricing.perVisit,
      description: t.pricing.premiumDesc,
      features: t.pricing.premiumFeatures,
      popular: false,
    },
  ];

  return (
    <section id="pricing" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 animate-fade-in-up">
          <span className="text-primary font-semibold uppercase tracking-wider text-sm">
            {t.pricing.subtitle}
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            {t.pricing.title}
          </h2>
          <p className="text-muted-foreground">
            {t.pricing.description}
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={plan.name}
              className={`relative rounded-3xl p-8 transition-all duration-300 hover:-translate-y-2 animate-fade-in-up flex flex-col ${
                plan.popular
                  ? "bg-primary text-primary-foreground shadow-elevated scale-105"
                  : "bg-background shadow-card"
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground px-4 py-1 rounded-full text-sm font-semibold">
                  {t.pricing.mostPopular}
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className={`text-xl font-semibold mb-2 ${plan.popular ? "text-primary-foreground" : "text-foreground"}`}>
                  {plan.name}
                </h3>
                <div className="flex items-baseline justify-center gap-1">
                  <span className={`text-5xl font-bold ${plan.popular ? "text-primary-foreground" : "text-primary"}`}>
                    €{plan.price}
                  </span>
                  <span className={plan.popular ? "text-primary-foreground/80" : "text-muted-foreground"}>
                    {plan.period}
                  </span>
                </div>
                <p className={`mt-2 text-sm ${plan.popular ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                  {plan.description}
                </p>
              </div>

              <ul className="space-y-4 mb-8 flex-grow">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      plan.popular ? "bg-primary-foreground/20" : "bg-accent/20"
                    }`}>
                      <Check className={`w-3 h-3 ${plan.popular ? "text-primary-foreground" : "text-accent"}`} />
                    </div>
                    <span className={`text-sm ${plan.popular ? "text-primary-foreground/90" : "text-foreground"}`}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>
              
              <Link href="/#contact" className="w-full mt-auto">
                <Button
                  variant={plan.popular ? "secondary" : "hero"}
                  size="lg"
                  className="w-full"
                >
                  {t.pricing.choosePlan}
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
