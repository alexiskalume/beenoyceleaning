'use client';
import { Home, Building2, Sparkles, Wind, Car, Leaf } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import Image from "next/image";
import Link from "next/link";
import placeholderImages from "@/lib/placeholder-images.json";
import { Translations } from "@/lib/translations";

type ServiceKey = keyof Omit<Translations['services'], 'subtitle' | 'title' | 'description'>;

const ICONS: { [key in ServiceKey]: React.ElementType } = {
    residential: Home,
    commercial: Building2,
    deep: Sparkles,
    windows: Wind,
    vehicle: Car,
    eco: Leaf,
};

interface ServicesSectionProps {
  showTitle?: boolean;
}

const ServicesSection = ({ showTitle = true }: ServicesSectionProps) => {
  const { t } = useLanguage();
  
  const serviceKeys = Object.keys(ICONS) as ServiceKey[];

  return (
    <section id="services" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        {showTitle && (
          <div className="text-center max-w-2xl mx-auto mb-12 animate-fade-in-up">
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">
              {t.services.subtitle}
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
              {t.services.title}
            </h2>
            <p className="text-muted-foreground">
              {t.services.description}
            </p>
          </div>
        )}

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceKeys.map((key, index) => {
            const service = t.services[key];
            const Icon = ICONS[key];
            const imageInfo = placeholderImages.services[key];
            
            return (
            <Link href={`/services/${key}`} key={key} className="block">
              <div
                className="group bg-background rounded-2xl overflow-hidden shadow-card hover:shadow-elevated transition-all duration-300 hover:-translate-y-2 animate-fade-in-up h-full flex flex-col"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={imageInfo.src}
                    alt={service.title}
                    fill
                    data-ai-hint={imageInfo.hint}
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                </div>
                
                {/* Content */}
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground flex-grow">
                    {service.description}
                  </p>
                </div>
              </div>
            </Link>
          )})}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
