'use client';
import { useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

import { submitContactForm, type ContactFormValues } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Phone, Mail, MapPin, Send, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
import { Translations } from "@/lib/translations";

// Define a more specific type for service keys that are objects
type ServiceObjectKey = keyof Omit<Translations['services'], 'subtitle' | 'title' | 'description'>;

const ContactSection = () => {
  const { t } = useLanguage();
  const [isPending, startTransition] = useTransition();

  // Filter keys to only include actual service objects, with type safety
  const serviceKeys = (Object.keys(t.services) as Array<keyof Translations['services']>)
    .filter((key): key is ServiceObjectKey => typeof t.services[key] === 'object');
  
  const serviceOptions = serviceKeys.map(key => ({
    value: key,
    label: t.services[key].title,
  }));

  // Create a dynamic Zod schema that uses translated error messages
  const contactFormSchema = z.object({
    name: z.string().min(2, { message: t.contact.form.validation.name }),
    email: z.string().email({ message: t.contact.form.validation.email }),
    phone: z.string().min(6, { message: t.contact.form.validation.phone }),
    service: z.string().min(1, { message: t.contact.form.validation.service }),
    message: z.string().min(10, { message: t.contact.form.validation.message }),
  });

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      service: "",
      message: "",
    },
  });

  const onSubmit = (values: ContactFormValues) => {
    startTransition(async () => {
      const result = await submitContactForm(values);
      if (result.success) {
        toast.success(t.contact.form.successMessage);
        form.reset();
      } else {
        toast.error(result.message);
      }
    });
  };

  const contactInfo = [
    { icon: Phone, label: t.contact.phone, value: t.contact.phoneValue },
    { icon: Mail, label: t.contact.email, value: t.contact.emailValue },
    { icon: MapPin, label: t.contact.address, value: t.contact.addressValue },
  ];

  return (
    <section id="contact" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left - Contact Info */}
          <div className="animate-slide-in-from-left">
            <span className="text-primary font-semibold uppercase tracking-wider text-sm">
              {t.contact.subtitle}
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
              {t.contact.title}
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              {t.contact.description}
            </p>

            <div className="space-y-6 mb-8">
              {contactInfo.map((item) => (
                <div key={item.label} className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">{item.label}</div>
                    <div className="font-semibold text-foreground">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA Box */}
            <div className="gradient-primary rounded-2xl p-6 text-primary-foreground">
              <h3 className="text-xl font-semibold mb-2">{t.contact.ctaTitle}</h3>
              <p className="text-primary-foreground/80 mb-4">
                {t.contact.ctaDesc}
              </p>
              <div className="flex items-center gap-3">
                <Phone className="w-6 h-6" />
                <span className="text-2xl font-bold">{t.contact.phoneValue}</span>
              </div>
            </div>
          </div>

          {/* Right - Contact Form */}
          <div className="bg-background rounded-3xl p-8 shadow-elevated animate-slide-in-from-right">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.contact.form.fullName}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t.contact.form.yourName}
                            {...field}
                            className="h-12 rounded-xl"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.contact.form.phoneNumber}</FormLabel>
                        <FormControl>
                          <Input
                            type="tel"
                            placeholder={t.contact.form.phonePlaceholder}
                            {...field}
                            className="h-12 rounded-xl"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.contact.form.emailLabel}</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder={t.contact.form.emailPlaceholder}
                          {...field}
                          className="h-12 rounded-xl"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="service"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.contact.form.serviceLabel}</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="h-12 rounded-xl">
                            <SelectValue placeholder={t.contact.form.selectService} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {serviceOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.contact.form.messageLabel}</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder={t.contact.form.messagePlaceholder}
                          rows={4}
                          className="rounded-xl resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" variant="hero" size="xl" className="w-full" disabled={isPending}>
                  {isPending ? <Loader2 className="animate-spin" /> : <Send className="w-5 h-5" />}
                  {t.contact.form.submit}
                </Button>

                <p className="text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent" />
                  {t.contact.form.responseGuarantee}
                </p>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
