'use client';
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import Image from "next/image";
import Link from "next/link";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import placeholderImages from "@/lib/placeholder-images.json";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const navLinks = [
    { href: "/", label: t.nav.home },
    { href: "/services", label: t.nav.services },
    { href: "/#about", label: t.nav.about },
    { href: "/#pricing", label: t.nav.pricing },
    { href: "/#contact", label: t.nav.contact },
  ];

  const languages = [
    { code: "en", name: "English", flag: "🇬🇧" },
    { code: "fi", name: "Suomi", flag: "🇫🇮" },
  ];

  const selectedLanguage = languages.find(lang => lang.code === language);

  return (
    <header className="sticky top-0 left-0 right-0 z-50 gradient-hero rounded-lg mx-4 my-2">
      <div className="container mx-auto px-10">
        <div className="flex items-center justify-between h-14 md:h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <Image 
              src={placeholderImages.header.logo.src} 
              alt="Been Oy" 
              width={placeholderImages.header.logo.width} 
              height={placeholderImages.header.logo.height} 
              className="h-10 md:h-12 w-auto" 
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-muted-foreground hover:text-primary transition-colors font-medium text-sm"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right side - Phone, Language, CTA, Menu */}
          <div className="flex items-center gap-3 md:gap-4">
            {/* Phone - hidden on mobile */}
            <a href={`tel:${t.contact.phoneValue}`} className="hidden md:flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
              <Phone className="w-3 h-3" />
              <span className="font-medium text-sm hidden lg:inline">{t.contact.phoneValue}</span>
            </a>
            
            {/* Language Switcher - always visible */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-2 px-2 py-1 rounded-lg border border-border hover:bg-secondary transition-colors"
                >
                  <span className="text-lg">{selectedLanguage?.flag}</span>
                  <span className="font-medium text-xs uppercase">{selectedLanguage?.code}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {languages.map((lang) => (
                    <DropdownMenuItem key={lang.code} onClick={() => setLanguage(lang.code as "en" | "fi")}>
                        <span className="mr-2 text-lg">{lang.flag}</span>
                        <span>{lang.name}</span>
                    </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* CTA Button - hidden on mobile */}
            <Link href="/#contact" className="hidden md:flex">
              <Button variant="hero" size="sm" className="h-9 text-xs">
                {t.nav.freeQuote}
              </Button>
            </Link>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden p-2 text-foreground"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border animate-fade-in-up">
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="text-foreground hover:text-primary transition-colors font-medium py-2 text-sm"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <a href={`tel:${t.contact.phoneValue}`} className="flex items-center gap-2 text-muted-foreground py-2 text-sm">
                <Phone className="w-4 h-4" />
                <span className="font-medium">{t.contact.phoneValue}</span>
              </a>
              <Link href="/#contact" className="mt-2 w-full" onClick={() => setIsMenuOpen(false)}>
                  <Button variant="hero" size="sm" className="w-full h-10 text-sm">
                    {t.nav.freeQuote}
                  </Button>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
