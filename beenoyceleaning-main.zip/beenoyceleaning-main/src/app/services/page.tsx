import ServicesSection from "@/components/ServicesSection";
import { Metadata } from "next";
import { translations } from "@/lib/translations";
import { Sparkles } from "lucide-react";

const t = translations.fi; // For metadata

export const metadata: Metadata = {
  title: t.nav.services,
  description: t.services.description,
  alternates: {
    canonical: "/services",
  },
  openGraph: {
    title: `${t.nav.services} | Been Oy`,
    description: t.services.description,
    url: "/services",
  },
};

const ServicesPage = () => {
  return (
    <>
      {/* Mini Hero Section */}
      <section className="py-12 md:py-20 gradient-hero">
        <div className="container mx-auto px-4 text-center animate-fade-in-up">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 mb-4">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">
              {t.services.subtitle}
            </span>
          </div>
          <h1 className="text-4xl font-bold text-foreground md:text-5xl">
            {t.services.title}
          </h1>
          <p className="mx-auto mt-4 max-w-3xl text-lg text-muted-foreground">
            {t.services.description}
          </p>
        </div>
      </section>

      {/* Services Section */}
      <ServicesSection showTitle={false} />
    </>
  );
};

export default ServicesPage;
